const NoMatch = ()=>{
    return(
        <>
        NoMatch
        </>
    )
}

export default NoMatch;
